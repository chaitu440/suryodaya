<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
    <title>SRI SURODAYA</title>

    <style>
.marquee-container {
    overflow: hidden;
}

.marquee-inner {
    display: flex;
    animation: marquee 20s linear infinite;
}

.marquee-item {
    margin-right: 20px; /* Adjust the spacing between logos */
    transition: height 0.5s ease; /* Smooth transition for height change */
}

.marquee-item:hover {
    height: 20px; /* Adjust the reduced height on hover */
}

@keyframes marquee {
    from {
        transform: translateX(100%);
    }
    to {
        transform: translateX(-100%);
    }
}
</style>

</head>

<body>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Create a container for the header
            var headerContainer = document.createElement('div');
            headerContainer.id = 'header-container';

            fetch('header.php')
                .then(response => response.text())
                .then(data => {
                    headerContainer.innerHTML = data;
                    document.body.insertBefore(headerContainer, document.body.firstChild);
                })
                .catch(error => console.error('Error fetching header:', error));
        });
    </script>

    <div id="home-content">
        <!-- Bootstrap Carousel -->
        <?php
// Connect to your database
$servername = "localhost";
$username = "srisuryo_suryodaya";
$password = "Aptit@789@312";
$dbname = "srisuryo_srisuryodaya";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch carousel data from the database
$sql = "SELECT carouselImage FROM carousel";
$result = $conn->query($sql);

// Store carousel images in an array
$carouselImages = [];
while ($row = $result->fetch_assoc()) {
    $imagePath = $row['carouselImage'];
    $carouselImages[] =  'admin/' . $imagePath; // Adjust the path here
}

// Close the database connection
$conn->close();
?>

<!-- Generate carousel HTML dynamically -->
<div id="carouselExample" class="carousel slide" data-ride="carousel"  data-interval="3000">
    <div class="carousel-inner">
        <?php
        // Generate carousel items dynamically
        foreach ($carouselImages as $index => $image) {
            $isActive = $index === 0 ? 'active' : '';
            echo '<div class="carousel-item ' . $isActive . ' text-center">';
            echo '<img src="' . $image . '" class="d-block mx-auto w-75" style="height: 400px;" alt="Slide ' . ($index + 1) . '">';
            echo '</div>';
            
        }
        ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExample" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExample" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>










<section id="value" class="v-wrapper ml-3 mt-3">
    <div class="paddings innerWidth flexCenter v-container">
        <div class="row">
            <div class="col-md-6">
                <div class="flexColStart v-left">
                    <div class="mb-3 d-flex align-items-center">
                        <i class="fas fa-circle mr-2" style="color: #ff5e15;"></i>
                        <p class="mb-0" style="color: #ff5e15;">WE PROMISE UR DREAMS</p>
                    </div>

                    <span class="primaryText mb-3" style="color: #ff4e00; font-size: 4rem;">SRI SURYODAYA</span>

                    <div class="secondaryTextContainer mb-5">
                        <span class="verticalLine">
                            <span class="secondaryText mb-3 ml-3">
                                Constructions - Class-I Contractors
                                <br />
                                <span class="secondaryText mb-3 ml-3">
                                    Interior Works
                                </span>
                                <br />
                                <span class="secondaryText mb-3 ml-3">
                                    Manufacturers of uPVC Windows & Doors
                                </span>
                            </span>
                        </span>
                    </div>

                    <div class="card mb-4 w-75 h-25 mr-4" style="text-align: justify;">
                        Sri Suryodaya Constructions, a recognized class-I firm
                        <br />
                        (Railways, University, ports, etc.) <br /> in & around Visakhapatnam, was established in 1991 by Sri Venkatapathi Raju.......
                    </div>
                    <button type="submit" class="button-48" role="button" onclick="handleButtonClick" style="font-size: 1vw;">
                        <span class="text">About Us</span>
                    </button>
                </div>
            </div>
            <div class="col-md-6">
                <div class="v-right">
                    <div class="image-container">
                        <img src="images/about.jpeg" alt="" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>





        <?php
// Connect to your database
$servername = "localhost";
$username = "srisuryo_suryodaya";
$password = "Aptit@789@312";
$dbname = "srisuryo_srisuryodaya";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch category data from the database
$getAllCategoriesQuery = "SELECT categoryid, categoryname, categoryImage FROM category";
$result = $conn->query($getAllCategoriesQuery);

// Store category images in an array
$categories = [];
while ($row = $result->fetch_assoc()) {
    // Convert the BLOB to base64
    $imageData = $row['categoryImage'];

    // Remove the original BLOB column
    unset($row['categoryImage']);

    // Add the base64-encoded image data to the row
    $row['categoryImageData'] = 'admin/' . $imageData;

    $categories[] = $row;
}

// Close the database connection
$conn->close();
?>

<!-- Display category images dynamically -->
<div class="categories mt-4">
    <p class="text-center">OUR SERVICES</p>
    <section class="cat-wrapper mt-3">
        <div class="paddings innerWidth flexCenter cat-container d-flex">
            <?php foreach ($categories as $category) : ?>
                <div class="category-card ml-3 p-1 shadow text-center" style="width: 250px; height:250px;">
                    <img
                        class="img-fluid mx-auto d-block mb-3"
                        src="<?php echo $category['categoryImageData']; ?>"
                        alt="<?php echo $category['categoryname']; ?>"
                        style="max-width: 100px; max-height: 100px;"
                    />
                    <p class="category-name"><?php echo $category['categoryname']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>



<p class="text-center">CONSTRUCTION PROJECTS </p>
<h1 class="text-center">Our Recent Projects</h1>
<?php
// Connect to your database
$servername = "localhost";
$username = "srisuryo_suryodaya";
$password = "Aptit@789@312";
$dbname = "srisuryo_srisuryodaya";
$con = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Fetch product data from the database
$getAllProductsQuery = "SELECT * FROM product";
$result = $con->query($getAllProductsQuery);

// Store product data in an array
$products = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $product = [
            "productid" => $row["productid"],
            "productname" => $row["productname"],
            "productimage" => $row["productimage"],
            "location" => $row["location"],
            "status" => $row["status"],
            "description" => $row["description"],
            "subcategoryid" => $row["subcategoryid"],
        ];

        $products[] = $product;
    }
}

// Close the database connection
$con->close();
?>

<div class="products mt-4">
    <p class="text-center">OUR PRODUCTS</p>
    <section class="product-wrapper mt-3">
        <div class="paddings innerWidth flexCenter product-container d-flex">
            <?php foreach ($products as $product) : ?>
                <div class="product-card mr-3 p-1 shadow text-center w-25 h-25">
                    <img class="w-75 h-75 mx-auto mb-3"
                         src="admin/<?php echo $product['productimage']; ?>"
                         alt="<?php echo $product['productname']; ?>"
                    />

                    <p class="product-name"><?php echo $product['productname']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>

        <?php
// Connect to your database
$servername = "localhost";
$username = "srisuryo_suryodaya";
$password = "Aptit@789@312";
$dbname = "srisuryo_srisuryodaya";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch client data from the database
$clientSql = "SELECT * FROM client";
$clientResult = $conn->query($clientSql);

// Store client logos in an array
$clientLogos = [];
while ($clientRow = $clientResult->fetch_assoc()) {
    $logoData = $clientRow['logos'];
    $clientLogos[] = 'admin/' . $logoData;
}

// Close the database connection
$conn->close();
?>

<!-- Display client logos dynamically -->
<div class="clients">
    <section class="c-wrapper mt-3">
        <div class="paddings innerWidth flexCenter c-container marquee-container">
            <div class="marquee-inner">
                <?php foreach ($clientLogos as $clientLogo) : ?>
                    <img
                        class="marquee-item w-25 h-25"
                        src="<?php echo $clientLogo; ?>"
                        alt="Client Logo"
                    />
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</div>


    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var footerContainer = document.createElement('div');
            footerContainer.id = 'footer-container';

            fetch('footer.php')
                .then(response => response.text())
                .then(data => {
                    footerContainer.innerHTML = data;
                    document.body.appendChild(footerContainer);
                })
                .catch(error => console.error('Error fetching footer:', error));
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>
