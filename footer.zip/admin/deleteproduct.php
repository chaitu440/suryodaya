<?php
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    // Database connection details
    $servername = "localhost";
    $username = "srisuryo_suryodaya";
    $password = "Aptit@789@312";
    $dbname = "srisuryo_srisuryodaya";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $productid = $_GET["id"];

    // Delete the product based on productid
    $sql = "DELETE FROM product WHERE productid = $productid";
    if ($conn->query($sql) === TRUE) {
        echo "Product deleted successfully";
    } else {
        echo "Error deleting product: " . $conn->error;
    }

    $conn->close();
} else {
    echo "Invalid request";
}
?>
