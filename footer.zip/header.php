<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>SRI SURYODAYA </title>
    <style>
.custom-button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #007bff; /* Set your desired background color */
    border: 2px solid #007bff; /* Set your desired border color */
    color: #fff; /* Set your desired text color */
    border-radius: 5px; /* Optional: Add rounded corners */
    text-decoration: none;
    font-size: 18px;
    transition: transform 0.3s ease-in-out; /* Add a smooth transition effect */
}

.custom-button:hover {
    color: #fff;
    border-color: #0056b3; /* Set your desired border color on hover */
    transform: translateY(-5px); /* Add a 5px vertical translation on hover */
}

</style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
    <a class="navbar-brand" href="index.php">
        <img src="images/logo.jpg" alt="Your Logo">
    </a>
    <h1 style="color: #ff4e00;">SRI SURYODAYA </h1>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto mr-auto"> <!-- ml-0 to move links to the left, mr-auto to move links to the right -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php" style="font-size: 18px;">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="aboutus.php" style="font-size: 18px;">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="upvc.php" style="font-size: 18px;">uPVC</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="gallery.php" style="font-size: 18px;">Projects</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="contactus.php" style="font-size: 18px;">Contact Us</a>
            </li>
            <li class="nav-item ml-0">
                <a class="custom-button " href="admin/adminlogin.php" style="font-size: 18px;">Login</a>
            </li>
        </ul>
    </div>
</nav>




<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
